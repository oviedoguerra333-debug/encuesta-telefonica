# Encuesta Atención al Cliente — Telefónica

## Archivos del proyecto

```
encuesta-telefonica/
├── index.html                   ← Encuesta pública (cualquiera puede responder)
├── dashboard.html               ← Panel admin: respuestas + diagramas + borrar
├── netlify.toml                 ← Configuración de Netlify
├── package.json                 ← Dependencia: @netlify/blobs
└── netlify/
    └── functions/
        └── survey.js            ← API serverless (guardar / leer / borrar)
```

---

## Cómo subir a Netlify (paso a paso)

### Opción A — Netlify Drop (más fácil, sin cuenta de GitHub)

1. Ve a **https://app.netlify.com/drop**
2. **Arrastra toda la carpeta** `encuesta-telefonica/` al área de drop.
3. Netlify la publica en segundos con una URL automática tipo `https://algo-bonito-123.netlify.app`.

> ⚠️ Con Netlify Drop las funciones serverless **no se activan**.  
> Para que los datos se guarden en línea, usa la Opción B.

---

### Opción B — GitHub + Netlify (recomendado)

1. Sube la carpeta a un repositorio de GitHub (puede ser privado).
2. En **https://app.netlify.com** → "Add new site" → "Import an existing project" → elige tu repo.
3. Netlify detectará el `netlify.toml` automáticamente. Haz clic en **Deploy**.

---

## Configurar la clave de administrador (IMPORTANTE)

La clave por defecto es `cambiar-esta-clave-secreta`. Cámbiala así:

1. En Netlify → tu sitio → **Site configuration** → **Environment variables**
2. Haz clic en **Add a variable**
3. Nombre: `ADMIN_KEY`
4. Valor: la clave que tú elijas (ej. `MiClave2025!`)
5. Haz clic en **Save**
6. Vuelve a hacer **Deploy** (o espera el re-deploy automático)

Con esa clave podrás entrar a `https://tu-sitio.netlify.app/dashboard.html`

---

## URLs de tu sitio una vez publicado

| URL | Descripción |
|-----|-------------|
| `https://tu-sitio.netlify.app/` | Encuesta pública |
| `https://tu-sitio.netlify.app/dashboard.html` | Panel de admin (pide clave) |

---

## Cómo funciona el almacenamiento

Las respuestas se guardan en **Netlify Blobs**, una base de datos key-value gratuita incluida en todos los planes de Netlify. No necesitas configurar ninguna base de datos externa.
